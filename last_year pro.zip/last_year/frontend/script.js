const API = "http://localhost:5000";

// ==========================================
// INITIALIZATION
// ==========================================
document.addEventListener("DOMContentLoaded", () => {
  // Automatically load data when the dashboard opens
  getStudents();
  getCompanies();
  getStats();
});

// ==========================================
// STUDENT MANAGEMENT
// ==========================================

function addStudent() {
  const name = document.getElementById("sname").value;
  const branch = document.getElementById("branch").value;
  const cgpa = document.getElementById("cgpa").value;

  if (!name || !branch || !cgpa) {
    alert("Please fill in all student details.");
    return;
  }

  fetch(API + "/students", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, branch, cgpa })
  })
  .then(res => res.json())
  .then(data => {
    alert("Student Onboarded Successfully");
    // Clear inputs
    document.getElementById("sname").value = "";
    document.getElementById("branch").value = "";
    document.getElementById("cgpa").value = "";
    
    // Refresh table and stats
    getStudents();
    getStats();
  })
  .catch(err => console.error("Error adding student:", err));
}

function getStudents() {
  const table = document.getElementById("studentTable");
  if (!table) {
    return;
  }

  fetch(API + "/students")
  .then(res => res.json())
  .then(data => {
    let rows = "";
    data.forEach(s => {
      const studentId = s.studentId || s._id || "-";
      // Create table rows instead of list items
      rows += `
        <tr>
          <td><strong>${studentId}</strong></td>
          <td><strong>${s.name}</strong></td>
          <td>${s.branch}</td>
          <td><span style="color: var(--primary); font-weight: bold;">${s.cgpa}</span></td>
        </tr>
      `;
    });
    table.innerHTML = rows;
  })
  .catch(err => console.error("Error fetching students:", err));
}

// ==========================================
// COMPANY MANAGEMENT
// ==========================================

function addCompany() {
  const name = document.getElementById("cname").value;
  const packageVal = document.getElementById("package").value;
  const minCGPA = document.getElementById("mincgpa").value;

  if (!name || !packageVal || !minCGPA) {
    alert("Please fill in all company details.");
    return;
  }

  fetch(API + "/companies", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, package: packageVal, minCGPA })
  })
  .then(res => res.json())
  .then(data => {
    alert("Corporate Partner Added Successfully");
    // Clear inputs
    document.getElementById("cname").value = "";
    document.getElementById("package").value = "";
    document.getElementById("mincgpa").value = "";
    
    // Refresh table and stats
    getCompanies();
    getStats();
  })
  .catch(err => console.error("Error adding company:", err));
}

function getCompanies() {
  const table = document.getElementById("companyTable");
  if (!table) {
    return;
  }

  fetch(API + "/companies")
  .then(res => res.json())
  .then(data => {
    let rows = "";
    data.forEach(c => {
      const companyId = c.companyId || c._id || "-";
      // Create table rows instead of list items
      rows += `
        <tr>
          <td><strong>${companyId}</strong></td>
          <td><strong>${c.name}</strong></td>
          <td>${c.package}</td>
          <td>Min CGPA: <strong>${c.minCGPA}</strong></td>
        </tr>
      `;
    });
    table.innerHTML = rows;
  })
  .catch(err => console.error("Error fetching companies:", err));
}

// ==========================================
// CAMPUS DRIVES & ELIGIBILITY
// ==========================================

function scheduleDrive() {
  const companyId = document.getElementById("companyId").value;
  const date = document.getElementById("date").value;

  if (!companyId || !date) {
    alert("Please provide Company ID and Date.");
    return;
  }

  fetch(API + "/drives", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ companyId, date })
  })
  .then(res => res.json())
  .then(data => {
    alert("Drive Scheduled Successfully");
    document.getElementById("companyId").value = "";
    document.getElementById("date").value = "";
    getStats();
  })
  .catch(err => console.error("Error scheduling drive:", err));
}

function checkEligibility() {
  const companyId = document.getElementById("checkCompanyId").value;
  const listEl = document.getElementById("eligibleList");
  
  if (!companyId) {
    alert("Please enter a Company ID.");
    return;
  }

  if (!listEl) {
    return;
  }

  fetch(API + `/drives/eligible/${companyId}`)
  .then(res => res.json())
  .then(data => {
    let list = "";
    const students = data.eligibleStudents || [];

    if (students.length === 0) {
      list = `<li>No eligible students found for this criteria.</li>`;
    } else {
      list = `<li><strong>${data.company}</strong> eligibility list</li>`;
      students.forEach(student => {
        const studentId = student.studentId || student._id || "-";
        list += `<li><i class="fa-solid fa-check"></i> ${student.name} (${student.branch}) - ${studentId} - CGPA: ${student.cgpa}</li>`;
      });
    }
    listEl.innerHTML = list;
  })
  .catch(err => console.error("Error checking eligibility:", err));
}

// ==========================================
// DASHBOARD KPI STATS
// ==========================================

function getStats() {
  fetch(API + "/drives/stats")
  .then(res => res.json())
  .then(data => {
    // Select the H3 tags inside the KPI cards to inject the live numbers
    const kpiHeaders = document.querySelectorAll(".kpi-data h3");
    
    if(kpiHeaders.length >= 3) {
      kpiHeaders[0].innerText = data.totalStudents || "0";
      kpiHeaders[1].innerText = data.totalCompanies || "0";
      kpiHeaders[2].innerText = data.totalDrives || "0";
    }
  })
  .catch(err => console.error("Error fetching stats:", err));
}
const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  studentId: { type: String, unique: true },
  name: String,
  branch: String,
  cgpa: Number,
});

module.exports = mongoose.model("Student", studentSchema);

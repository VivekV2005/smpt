const mongoose = require("mongoose");

const companySchema = new mongoose.Schema({
  companyId: { type: String, unique: true },
  name: String,
  package: String,
  minCGPA: Number,
});

module.exports = mongoose.model("Company", companySchema);
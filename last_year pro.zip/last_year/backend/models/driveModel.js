const mongoose = require("mongoose");

const driveSchema = new mongoose.Schema({
  driveId: { type: String, unique: true },
  companyId: String,
  date: String,
});

module.exports = mongoose.model("Drive", driveSchema);
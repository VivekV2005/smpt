const express = require("express");
const router = express.Router();
const Company = require("../models/companyModel");
const { getNextId } = require("../utils/idGenerator");

// Add company
router.post("/", async (req, res) => {
  try {
    const company = new Company({
      ...req.body,
      companyId: await getNextId("company", "COM"),
    });
    await company.save();
    res.status(201).send(company);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all companies
router.get("/", async (req, res) => {
  try {
    const companies = await Company.find();
    res.status(200).send(companies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const Drive = require("../models/driveModel");
const Company = require("../models/companyModel");
const Student = require("../models/studentModel");
const { getNextId } = require("../utils/idGenerator");

// Create drive
router.post("/", async (req, res) => {
  try {
    const drive = new Drive({
      ...req.body,
      driveId: await getNextId("drive", "DRV"),
    });
    await drive.save();
    res.status(201).send(drive);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get eligible students for a company
router.get("/eligible/:companyId", async (req, res) => {
  try {
    const { companyId } = req.params;
    let company = null;

    if (mongoose.Types.ObjectId.isValid(companyId)) {
      company = await Company.findById(companyId);
    }

    if (!company) {
      company = await Company.findOne({ companyId });
    }

    if (!company) {
      return res.status(404).json({ message: "Company not found" });
    }

    const students = await Student.find({
      cgpa: { $gte: company.minCGPA }
    });

    return res.status(200).send({
      company: company.name,
      eligibleStudents: students
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
});

// Simple analytics
router.get("/stats", async (req, res) => {
  try {
    const totalStudents = await Student.countDocuments();
    const totalCompanies = await Company.countDocuments();
    const totalDrives = await Drive.countDocuments();

    res.status(200).send({
      totalStudents,
      totalCompanies,
      totalDrives
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
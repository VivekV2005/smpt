const express = require("express");
const router = express.Router();
const Student = require("../models/studentModel");
const { getNextId } = require("../utils/idGenerator");

// Add student
router.post("/", async (req, res) => {
  try {
    const student = new Student({
      ...req.body,
      studentId: await getNextId("student", "STU"),
    });
    await student.save();
    res.status(201).send(student);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get all students
router.get("/", async (req, res) => {
  try {
    const students = await Student.find();
    res.status(200).send(students);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
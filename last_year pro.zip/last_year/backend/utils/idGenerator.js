const Counter = require("../models/counterModel");

const padNumber = (value, size) => String(value).padStart(size, "0");

const getNextId = async (key, prefix, width = 4) => {
  const counter = await Counter.findOneAndUpdate(
    { key },
    { $inc: { seq: 1 } },
    { new: true, upsert: true }
  );

  return `${prefix}-${padNumber(counter.seq, width)}`;
};

module.exports = { getNextId };

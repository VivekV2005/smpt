// ==========================================
// CORE MODULES & CONFIGURATION
// ==========================================
require("dotenv").config(); 
const express = require("express");
const cors = require("cors");
const helmet = require("helmet"); 
const morgan = require("morgan"); 

// Import the modern database connection we created
const connectDB = require("../database/db"); 

const app = express();

// ==========================================
// INITIALIZE DATABASE
// ==========================================
connectDB();

// ==========================================
// MIDDLEWARE (The Request Pipeline)
// ==========================================
app.use(helmet()); 

app.use(cors({
  origin: process.env.FRONTEND_URL || "*", 
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== "production") {
  app.use(morgan("dev")); 
}

// ==========================================
// ROUTE REGISTRATION
// ==========================================
const studentRoutes = require("./routes/studentRoutes");
const companyRoutes = require("./routes/companyRoutes");
const driveRoutes = require("./routes/driveRoutes");

// 👇 I COMMENTED THIS OUT FOR YOU 👇
// const eligibilityRoutes = require("./routes/eligibilityRoutes"); 

app.use("/students", studentRoutes);
app.use("/companies", companyRoutes);
app.use("/drives", driveRoutes);

// 👇 I COMMENTED THIS OUT FOR YOU 👇
// app.use("/eligibility", eligibilityRoutes); 

// Health Check Route 
app.get("/health", (req, res) => {
  res.status(200).json({ status: "success", message: "🚀 Elevate PMS API is healthy and running." });
});

// ==========================================
// GLOBAL ERROR HANDLER
// ==========================================
app.use((err, req, res, next) => {
  console.error(`❌ Server Error: ${err.message}`);
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode).json({
    status: "error",
    message: err.message,
    stack: process.env.NODE_ENV === "production" ? "🥞" : err.stack,
  });
});

// ==========================================
// SERVER BOOTSTRAP & GRACEFUL SHUTDOWN
// ==========================================
const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, () => {
  // 👇 THIS LINE HAS BEEN UPDATED TO PRINT THE URL 👇
  console.log(`🚀 Server running in ${process.env.NODE_ENV || "development"} mode at http://localhost:${PORT}`);
});

process.on("unhandledRejection", (err, promise) => {
  console.error(`💥 Unhandled Rejection: ${err.message}`);
  server.close(() => process.exit(1));
});
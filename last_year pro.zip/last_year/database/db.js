const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    mongoose.set("strictQuery", true);

    // Uses the environment variable if available, otherwise falls back to your local DB
    const MONGO_URI = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/placementDB";

    const conn = await mongoose.connect(MONGO_URI);

    console.log(`✅ Database Connected Successfully: ${conn.connection.name} @ ${conn.connection.host}`);

    mongoose.connection.on('error', (err) => {
      console.error(`❌ Database Runtime Error: ${err.message}`);
    });

    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️ Database connection lost. Attempting to reconnect...');
    });

  } catch (error) {
    console.error(`❌ Critical Database Connection Error: ${error.message}`);
    process.exit(1); 
  }
};

module.exports = connectDB;